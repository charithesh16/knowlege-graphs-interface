from flask import Flask
from flask import request
from flask_cors import CORS
import gpt
import db

app = Flask(__name__)
CORS(app)

@app.route('/getGraph',methods=['POST','GET'])
def generateGraph():
    print("hello")
    data = request.get_json()
    # gets list of dictionaries of the form {source:$source,label:$label,target:$target}
    relations = gpt.getRelations(data["prompt"])

    # save the relations to neo4j database.

    #return the relations.

    print(relations)

    db.save_relations(relations)
    return "Hello"

@app.route('/getexistinggraph')
def  getExistingGraph():
    return

@app.route('/deletedata')
def deleteGraph():
    return

@app.route('/addEdge')
def addEdge():
    return
