from neo4j import GraphDatabase

URI = "neo4j+ssc://c0680b05.databases.neo4j.io"
AUTH = ("neo4j","CpnJ1GvpwPe1RLKrJW1yI16KTsE-PZjuXZbbV4mRvME")


def get_driver():
    with GraphDatabase.driver(URI,auth = AUTH) as driver:
        # driver.verify_connectivity
        return driver
    return None

def save_relations(relations):
    driver = get_driver()
    if driver == None:
        print("Error connecting to Database")
        return
    nodes = set()
    for relation in relations:
        source = str(relation["source"]).replace(" ","_")
        target = str(relation["target"]).replace(" ","_")
        # Create nodes
        create_node(driver,source)
        create_node(driver,target)
        # records,summary,keys = driver.execute_query("""MERGE (n:Node {name:$name})""",name=source,database_="neo4j")
    return

def create_node(driver,node_name):
    create_query = """ MERGE (n:Node {name:\" """ + node_name + """\"})"""
    print(create_query)
    records,summary,keys = driver.execute_query(create_query,database_="neo4j")
    print(summary)
    return